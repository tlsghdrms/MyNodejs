function greeting(name) {
    return `안녕하세요, ${name}님!`;
}

console.log(greeting("홍길동"));

