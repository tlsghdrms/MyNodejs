const numbers = [1, 2, 3, 4, 5];

numbers.forEach(function(num) {
    console.log("현재 숫자:", num);
})