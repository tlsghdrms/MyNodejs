// export function add(a, b) {
//     return a + b;
// }

export const PI = 3.14;

export function circleArea(radius) {
    return PI * radius * radius;
}

export function circleCircumference(radius) {
    return 2 * PI * radius;
}