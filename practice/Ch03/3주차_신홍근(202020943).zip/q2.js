
const writeData = require('./file.js');

const data = 'This is sample of mine';
writeData('./mydata.txt', data);